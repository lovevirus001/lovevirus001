version_flag = "v0.0.2"

from scripts.roop_logging import logger

logger.info(f"roop {version_flag}")
